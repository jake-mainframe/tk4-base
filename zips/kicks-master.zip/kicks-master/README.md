# KICKS

KICKS works much like CICS. It has a very similar EXEC API, and works inside TSO on MVS 3.8

KICKS is an enhacement for CMS and TSO on IBM mainframes and emulators that lets you run your CICS applications directly instead of having ot install those apps in CICS. You don't even need CICS itself instald on your mainframe. 

KICKS is high level source code compatible with CICS. You can migrate your apps either way between CICS and KICKS by recompiling. 

Great for testing, for prototyping or for small groups of users, KICKS is an amazing platform. 

go read more at: www.kicksfortso.com
